# coding: utf-8

def plot_random_walk2():
    fig = plt.figure(figsize=(8, 6))
    ax = fig.add_subplot(111)  # equivalent to ax = fig.add_subplot(1, 1, 1)
    ax.set_title("Figure 1")
    a = (np.random.random(100) - 0.5).cumsum()
    b = (np.random.random(100) - 0.5).cumsum()
    ax.plot(a, c='g')
    ax.plot(b, c='r')
    ax.axhline(y=a.mean(), color='g', ls=':')
    ax.axhline(y=b.mean(), color='r', ls=':')
    ax.legend(["Random walk 1", "Random walk 2"]);

plot_random_walk2()