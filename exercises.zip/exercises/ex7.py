# coding: utf-8

geo['Densité'] = geo['Population'] / geo['Superficie']

status = list(geo['Statut'].value_counts().index)
if pd.__version__ < '0.21.0':
    geo['Statut'] = geo['Statut'].astype('category', categories=status, ordered=True)
else:
    from pandas.api.types import CategoricalDtype
    cat_status = CategoricalDtype(categories=status, ordered=True)
    geo['Statut'] = geo['Statut'].astype(cat_status)

metro = geo.loc[geo['Latitude'] > 40]

# Noms des préfectures de région
plt.figure(figsize=(7, 5))
metro_A = metro.loc[metro["Statut"] >= "Préfecture"]
metro_A = metro_A.sort_values("Population", ascending=False)
metro_B = metro.loc[metro["Statut"] < "Préfecture"]

# communes
plt.scatter(metro_B["Longitude"],
            metro_B["Latitude"],
            c='y',
            s=3,
            edgecolors='none')

# préfectures
ax = plt.scatter(metro_A["Longitude"],
                metro_A["Latitude"],
                c=metro_A["Densité"],
                s=metro_A["Population"],
                cmap=plt.cm.Reds,
                edgecolors='none')

# noms des préfectures de région hors PLM
metro_C = metro.loc[(metro["Statut"] >= "Préfecture de région") & ~metro["Commune"].str.contains("ARRONDISSEMENT")]
for i, row in metro_C.iterrows():
    plt.text(row["Longitude"],
                 row["Latitude"],
                 row["Commune"].title(),
                 fontsize=8)
    
plt.colorbar(ax);