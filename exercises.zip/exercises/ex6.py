# coding: utf-8

# Metropolitan France
metro = geo.loc[geo['Latitude'] > 40]
plt.scatter(metro['Longitude'],
            metro['Latitude'],
            s=3);

metro = metro.sort_values('Altitude Moyenne')
plt.scatter(metro['Longitude'],
            metro['Latitude'],
            c=metro['Altitude Moyenne'],
            s=3,
            cmap=plt.cm.coolwarm)
plt.colorbar();