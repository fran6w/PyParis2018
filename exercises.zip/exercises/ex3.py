# coding: utf-8

# compound graphics
fig, [[ax1, ax2, ax3], [ax4, ax5, ax6]] = plt.subplots(2, 3, figsize=(12, 6))

ax1.set_title("Figure 1")
ax1.plot(np.random.random(10))

ax2.set_title("Figure 2")
ax2.plot(np.random.random(10), 'r--')

ax3.set_title("Figure 3")
x = np.random.random(10)
ax3.plot(x, 'c:')
ax3.plot(x, '*', color='darkred')

ax4.set_title("Figure 4")
x = np.random.random(10)
ax4.plot(x, '-.', color='0.3')
ax4.plot(x, '^', color='#ff0080')

ax5.set_title("Figure 5")
x = np.random.random(10)
ax5.plot(x, '-', color='gold', lw=2)
ax5.plot(x, 's', color='k')

ax6.set_title("Figure 6")
x = np.random.random(10)
ax6.plot(x, '--', color='0.7')
ax6.plot(x, 'o', color='b');