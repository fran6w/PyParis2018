# coding: utf-8

# for each edition the ratio of medals by gender
table1 = pd.crosstab(df['Edition'], df['Gender'])
table1 = table1.div(table1.sum(axis=1), axis=0)
ax = table1.plot(kind='bar',
                 stacked=True,
                 figsize=(12, 4),
                 title="Medals by edition and gender")
ax.set_xticks(range(len(table1)))
ax.set_xlabel("Editions")
ax.set_xticklabels(table1.index);

# for each sport the number of medals by metal
table2 = pd.crosstab(df['Sport'], df['Medal'])
ax = table2.plot(kind='bar',
                figsize=(12, 4),
                 title="Medals by edition and metal")
ax.set_xticks(range(len(table2)))
ax.set_xlabel("Sports")
ax.set_xticklabels(table2.index);
