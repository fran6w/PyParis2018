# coding: utf-8

# graphics with subplots
table1 = pd.crosstab(df['Edition'], df['Medal'])
axes = table1.plot(figsize=(9, 6),
               title="Medals by metal and edition",
               kind='bar',
               subplots=True,
               #sharey=True,
               color=['darkorange', 'silver', 'gold'],
               rot=60)
plt.subplots_adjust(hspace=0.4)
axes[-1].set_xticks(range(len(table1)))
axes[-1].set_xlabel("Editions")
axes[-1].set_xticklabels(table1.index)
for ax in axes:
    ax.legend().set_visible(False);
    
# graphics with subplots
table2 = pd.crosstab(df['Sport'], df['Medal'])
axes = table2.plot(figsize=(9, 6),
               title="Medals by metal and sport",
               kind='bar',
               subplots=True,
               #sharey=True,
               color=['darkorange', 'silver', 'gold'],
               rot=60)
plt.subplots_adjust(hspace=0.4)
plt.xticks(ha='right')
axes[-1].set_xticks(range(len(table2)))
axes[-1].set_xlabel("Sports")
axes[-1].set_xticklabels(table2.index)
for ax in axes:
    ax.legend().set_visible(False);