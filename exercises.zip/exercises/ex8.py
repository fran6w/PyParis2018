# coding: utf-8

fig, ax = plt.subplots(figsize=(12, 2))
sns.heatmap(table1, cmap='Blues', ax=ax);
ax.set_xticklabels(table1.columns, rotation=60)
ax.set_yticklabels(table1.index, rotation=0)
ax.set_ylabel('Gender', rotation=0);

table2 = pd.crosstab(df['Sport'], df['Gender'])
table2.sort_values('Men', inplace=True)
fig, ax = plt.subplots(figsize=(5, 12))
sns.heatmap(table2, cmap='Blues', annot=True, fmt='d', ax=ax);

dfw = df.loc[df['Gender'] == 'Women']
table3 = pd.crosstab(dfw['Sport'], dfw['Edition']).apply(lambda x: x > 0).astype(int)
fig, ax = plt.subplots(figsize=(12, 8))
sns.heatmap(table3, cmap='Reds', cbar=False, ax=ax);
